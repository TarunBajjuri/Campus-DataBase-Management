Campus DataBase for Parking Managment System.
In this project, we are creating a campus database, in which we are calculating 
the percentage of parking utilized per block.
This project allows us to solve the problem that how much parking area is utilized  per block in the campus. 
We can also know how many 2-wheeler are parked in the parking lot and also we can know the no. of 4-wheelers are parked.
